package statemotorscorp;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class gradient extends JPanel { // Followed naming conventions

    private List<CustomColor> Colors; // Correct type

    public gradient() {
        setOpaque(false);
        Colors = new ArrayList<>();
    }

    public void addColor(CustomColor... colorPoints) { // Corrected parameter name
        for (CustomColor c : colorPoints) {
            Colors.add(c);
        }
    }    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
  
    
    @Override
    protected void paintComponent(Graphics grphcs) {
        super.paintComponent(grphcs); // Always call the superclass method first

       if (!Colors.isEmpty()) {
            int height = getHeight();
            int width = getWidth();
            Graphics2D g2 = (Graphics2D) grphcs;
            Color[] colorArray = new Color[Colors.size()];
            float[] positionArray = new float[Colors.size()];

            for (int i = 0; i < Colors.size(); i++) {
                colorArray[i] = Colors.get(i).getColor();
                positionArray[i] = Colors.get(i).getPosition();
            }

            int sx = 5;
            int sy = 5;
            int ex = width;
            int ey = 3;

            LinearGradientPaint gradientPaint = new LinearGradientPaint(
                sx, sy, ex, ey, positionArray, colorArray
            );
            g2.setPaint(gradientPaint);
            g2.fillRect(0, 0, width, height);
        }
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

