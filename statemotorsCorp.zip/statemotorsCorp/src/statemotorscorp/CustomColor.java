package statemotorscorp;

import java.awt.Color;

public class CustomColor {

    private Color color;
    private float position;

   public CustomColor(String hex, float position) {
        this.color = Color.decode(hex); // Decode hex to Color
        this.position = position;
    }

    public Color getColor() {
        return color;
    }
    
    public void setColor(String hex) {
        this.color = color;
    }

    public float getPosition() {
        return position;
    }
    
      public void setPosition(float position) {
        this.position = position;
    }
}